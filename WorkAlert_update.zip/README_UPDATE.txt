WorkAlert notification button layout update

Copy the archive contents into the repository root, preserving folder paths.
It replaces WorkAlertNotification.kt and adds two RemoteViews layouts and two button backgrounds.

The notification shows a grey VYPNÚŤ button on the left and a red SIGNÁL button on the right.
The buttons retain their existing receiver actions.

Android/Xiaomi may apply system notification decoration or restrict custom notification views.
Test the expanded and collapsed notification on the target Redmi device.
