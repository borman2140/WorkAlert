WorkAlert minimal notification update

This archive removes all non-button text from the custom notification.
It adds the WA logo at the left, a square grey X button, and a red SIGNÁL button
that fills the remaining width. The notification small icon and app launcher icon
are also changed to the WA artwork.

Replaces:
- app/src/main/java/sk/workalert/WorkAlertNotification.kt
- app/src/main/AndroidManifest.xml
- app/src/main/res/layout/notification_workalert.xml
- app/src/main/res/layout/notification_workalert_expanded.xml
- app/src/main/res/drawable/workalert_button_grey.xml
- app/src/main/res/drawable/workalert_button_red.xml

Adds:
- app/src/main/res/drawable-nodpi/workalert_logo.png
- app/src/main/res/drawable-nodpi/workalert_notification_small.png

The STOP action still restores the previous alarm volume and removes the notification.
The SIGNAL action still invokes AlertTone.play(). Sound and vibration implementation are unchanged.
