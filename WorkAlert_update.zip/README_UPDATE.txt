WorkAlert button proportions update

Replace the two notification layout files at their exact paths.
The grey VYPNÚŤ button is now 56dp wide and the red SIGNÁL button 112dp wide
in the compact notification. In the expanded notification, the width ratio is 1:2.
Button actions, colors, heights, sound, and vibration are unchanged.
