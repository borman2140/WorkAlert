WorkAlert exact icon artwork update

Uses the first supplied image as the launcher/app icon:
- app/src/main/res/drawable-nodpi/workalert_app_icon.png

Uses the second supplied image as the full-color notification large icon:
- app/src/main/res/drawable-nodpi/workalert_notification_full.png

Adds a monochrome bell glyph for Android's required small notification icon:
- app/src/main/res/drawable/workalert_notification_small.xml

Updates AndroidManifest.xml and WorkAlertNotification.kt to use these assets.
The notification layouts and button styling/actions are not changed.
Sound and vibration source files are not changed.

Android small notification icons are rendered as monochrome/tinted glyphs by the OS.
The full-color second artwork is supplied as the notification large icon, but the
lock-screen skin may choose to show only the monochrome small icon in its left badge.
