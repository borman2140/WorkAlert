WorkAlert notification-only icon correction

This update changes ONLY the notification artwork/layout:
- Removes the WA logo that was inside the dark custom notification panel.
- Uses the user's supplied round black/red bell artwork as the notification large icon.
- Uses a monochrome bell glyph for Android's required small notification icon, tinted red.
- Keeps the square X and red SIGNAL buttons and their existing actions.

IMPORTANT:
- The app launcher icon is NOT included and is NOT modified.
- Sound and vibration source files are NOT included and are NOT modified.
- Existing button drawable resources are referenced but not changed.
Copy the archive contents into the repository root, preserving paths.
