WorkAlert notification update

This ZIP contains only the files to add/replace in the existing repository.
Keep AlertTone.kt, AlertTileService.kt and all Gradle files unchanged.

Copy the contents of this ZIP into the repository root, preserving folders.
Replace app/src/main/AndroidManifest.xml.
Add/replace the three Kotlin files under app/src/main/java/sk/workalert/.

The app now posts an ongoing Android notification with SIGNÁL and VYPNÚŤ actions.
No full-screen lock-screen Activity is used.

After installing the APK:
1. Open WorkAlert and allow notifications.
2. Open Android Settings > Notifications > Lock screen notifications and allow WorkAlert content on lock screen.
3. On Xiaomi, allow WorkAlert notifications and enable lock-screen display.
4. Expand the notification on the lock screen if Android hides its action buttons in collapsed view.

Note: notification actions are Android system notification actions; Xiaomi/Android may require expanding the card to reveal buttons. This build has not been compiled on the user's device yet.
